import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from decide import dates_match, decide  # noqa: E402

CLAIM = {"name": "Jane Doe", "course": "Machine Learning", "date": "2024-03-15"}
GOOD = {"name": "Jane Doe", "course": "Machine Learning", "date": "2024-03-15"}


def test_verified():
    assert decide(CLAIM, GOOD, "OK")[0] == "VERIFIED"


def test_verified_ignores_case_and_order():
    got = {"name": "DOE, jane", "course": "machine learning", "date": "March 15, 2024"}
    assert decide(CLAIM, got, "OK")[0] == "VERIFIED"


def test_mismatch_name_names_the_field():
    res, reason, _ = decide(CLAIM, dict(GOOD, name="Jane Roe"), "OK")
    assert res == "MISMATCH" and "name" in reason


def test_mismatch_course_and_date():
    assert decide(CLAIM, dict(GOOD, course="Baking"), "OK")[0] == "MISMATCH"
    assert decide(CLAIM, dict(GOOD, date="2024-03-16"), "OK")[0] == "MISMATCH"


def test_not_found():
    assert decide(CLAIM, {}, "NO_RECORD")[0] == "NOT_FOUND"


def test_uncertain_when_blocked_timeout_error():
    for s in ("BLOCKED", "TIMEOUT", "ERROR"):
        assert decide(CLAIM, GOOD, s)[0] == "UNCERTAIN"


def test_uncertain_when_field_missing_never_verified():
    assert decide(CLAIM, dict(GOOD, name=None), "OK")[0] == "UNCERTAIN"
    assert decide(CLAIM, {}, "OK")[0] == "UNCERTAIN"


def test_month_only_issuer_date():
    assert dates_match("2024-03-15", "March 2024")
    assert not dates_match("2024-03-15", "April 2024")
