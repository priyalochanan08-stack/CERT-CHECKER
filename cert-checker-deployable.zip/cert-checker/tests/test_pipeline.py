import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import config  # noqa: E402
import db  # noqa: E402
import pipeline  # noqa: E402
import validation  # noqa: E402

FORM = dict(credential_id="GOOD1001", issuer="mock", candidate_name="Jane Doe",
            claimed_course="Machine Learning", claimed_date="2024-03-15", consent="yes")


def run(form):
    clean, errs = validation.validate(form)
    assert not errs, errs
    rid = pipeline.submit_record(clean)
    v = pipeline.view(rid)
    if v["plan"]:
        pipeline.approve(v["plan"]["plan_id"])
        pipeline.execute(v["plan"]["plan_id"])
    return rid, pipeline.view(rid)


def test_validation_rejects_bad_input():
    _, errs = validation.validate(dict(FORM, credential_id="x", claimed_date="not a date", candidate_name=""))
    assert len(errs) == 3


def test_consent_missing_queries_nothing(fresh):
    rid, v = run(dict(FORM, consent=""))
    assert v["status"] == "UNCERTAIN" and "Consent" in v["reason"]
    assert v["plan"] is None and v["execution"] is None


def test_verified_end_to_end_with_evidence(fresh):
    rid, v = run(FORM)
    assert v["status"] == "VERIFIED"
    assert v["verification"]["passed"] == 1
    assert os.path.isfile(os.path.join(config.EVIDENCE_DIR, v["execution"]["screenshot_path"]))


def test_badge_on_page_is_ignored(fresh):
    _, v = run(dict(FORM, credential_id="TRAP2002"))  # page shows VERIFIED badge, name is Alex Roe
    assert v["status"] == "MISMATCH"


def test_not_found_and_blocked(fresh):
    assert run(dict(FORM, credential_id="ZZZ999"))[1]["status"] == "NOT_FOUND"
    assert run(dict(FORM, credential_id="BLOCK001"))[1]["status"] == "UNCERTAIN"


def test_retry_never_executes_twice(fresh):
    rid, v = run(FORM)
    pid = v["plan"]["plan_id"]
    first = pipeline.execute(pid)
    second = pipeline.execute(pid)
    assert first == second
    assert db.q("SELECT COUNT(*) c FROM executions", one=True)["c"] == 1


def test_tamper_after_approval_is_refused(fresh):
    clean, _ = validation.validate(FORM)
    rid = pipeline.submit_record(clean)
    pid = pipeline.view(rid)["plan"]["plan_id"]
    assert pipeline.demo_tamper(pid) is None
    assert pipeline.view(rid)["status"] == "TAMPER_DETECTED"
    assert db.q("SELECT COUNT(*) c FROM executions", one=True)["c"] == 0


def test_unapproved_plan_does_not_run(fresh):
    clean, _ = validation.validate(FORM)
    pid = pipeline.view(pipeline.submit_record(clean))["plan"]["plan_id"]
    assert pipeline.execute(pid) is None
