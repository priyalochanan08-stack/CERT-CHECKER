import os
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import pytest  # noqa: E402

import config  # noqa: E402
import db  # noqa: E402
import mock_issuer  # noqa: E402


@pytest.fixture(scope="session", autouse=True)
def mock_server():
    srv = mock_issuer.start_background()
    yield
    if srv:
        srv.shutdown()


@pytest.fixture()
def fresh():
    d = tempfile.mkdtemp()
    config.EVIDENCE_DIR = os.path.join(d, "evidence")
    db.init(os.path.join(d, "t.db"))
    return d
